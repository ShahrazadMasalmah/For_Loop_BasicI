lowNum = 10
highNum = 20
mult = 5
for lowNum in range(lowNum, highNum+1, 1):
    if(lowNum % mult == 0):
        print(lowNum)