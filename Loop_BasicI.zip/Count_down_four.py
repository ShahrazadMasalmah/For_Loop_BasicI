for i in range(2018, 0, -4):
    print(i)