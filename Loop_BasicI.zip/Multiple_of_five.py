for i in  range(5,1001):
    if(i % 5 == 0):
        print(i)

        