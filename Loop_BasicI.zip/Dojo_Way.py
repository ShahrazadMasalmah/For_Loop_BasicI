for i in range(1, 101):
    if(i % 10 == 0):
        print("Coding Dojo")
    elif(i % 5 == 0):
        print("Coding") 
    else:
        print(i)       