sum = 0
for i in range(0, 500000):
    if(i % 2 != 0):
        sum += i
    
print(sum)        